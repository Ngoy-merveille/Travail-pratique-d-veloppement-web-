let randn = Math.floor(Math.random()*100)+1;
let guesse = document.querySelector(".guesse");
let lastr = document.querySelector(".lastr");
let lowo = document.querySelector(".lowo");
let gfield = document.querySelector(".gfield");
let gsubmit = document.querySelector(".gsubmit");
let gcount = 1;
let resetb;

function checkg()
{
    let userg=Number(gfield.value);
    if(gcount===1)
    {
        guesse.textContent='Propositions precedentes : ';
    }
    guesse.textContent += userg+ ' ';
    if (userg===randn)
    {
    lastr.textContent = "Bravo! Vous avez trouvé le nombre!";
    lastr.style.backgroundColor='magenta';
    lowo.textContent='';
    sgameo();
    }
    else if (gcount===10)
    {
        lastr.textContent='!!! PERDU !!!';
        sgameo();
    }
    else
    {
        lastr.textContent='Faux !';
        lastr.style.backgroundColor='red';
        if (userg < randn)
            {
                lowo.textContent='Le nombre est trop petit!';
            }
        else if (userg > randn)
            {
                lowo.textContent='Le nombre est trop grand!';
            }
    }
   
    gcount++;
    gfield.value='';
    gfield.focus();
}

gsubmit.addEventListener('click', checkg);

function sgameo()
{
    gfield.disabled=true;
    gsubmit.disabled=true;
    resetb=document.createElement('button');
    resetb.textContent='Start new game';
    document.body.appendChild(resetb);
    resetb.addEventListener('click', resetg);
}

function resetg()
{
   gcount = 1;
let resetp = document.querySelectorAll('.resultp p');
for (let i = 0 ; i < resetp.length ; i++)
{
   resetp[i].textContent = '';
}
resetb.parentNode.removeChild(resetb);
gfield.disabled = false;
gsubmit.disabled = false;
gfield.value = '';
gfield.focus();
lastr.style.backgroundColor = 'white';
randn = Math.floor(Math.random()* 100) + 1;
}